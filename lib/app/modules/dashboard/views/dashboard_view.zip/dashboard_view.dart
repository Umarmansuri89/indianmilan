import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:shyam_trust_flutter/app/modules/discover_girl/views/discover_girl_view.dart';
import 'package:shyam_trust_flutter/app/modules/faq_new/views/faq_new_view.dart';
import 'package:shyam_trust_flutter/app/modules/home/views/home_view.dart';

import 'package:shyam_trust_flutter/app/modules/settings/views/settings_view.dart';
import 'package:shyam_trust_flutter/app/routes/app_pages.dart';
import 'package:shyam_trust_flutter/app/utils/image_helper.dart';

import '../controllers/dashboard_controller.dart';

class DashboardView extends GetView<DashboardController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        color: Color(0xff0D0B21),
        child: PersistentTabView(
          context,
          controller: controller.persistentTabController,
          screens: buildScreens(),
          items: navBarsItems(),
          margin: EdgeInsets.all(5),
          confineInSafeArea: true,
          backgroundColor: Color(0xff19172C),
          // Default is Colors.white.
          handleAndroidBackButtonPress: true,
          padding: NavBarPadding.all(5),
          // Default is true.
          resizeToAvoidBottomInset: true,
          // This needs to be true if you want to move up the screen when keyboard appears. Default is true.
          stateManagement: true,
          // Default is true.
          hideNavigationBarWhenKeyboardShows: true,
          // Recommended to set 'resizeToAvoidBottomInset' as true while using this argument. Default is true.
          decoration: NavBarDecoration(
            borderRadius: BorderRadius.circular(10.0),
            colorBehindNavBar: Colors.transparent,
          ),
          navBarHeight: 65,
          popAllScreensOnTapOfSelectedTab: false,
          popActionScreens: PopActionScreensType.all,
          itemAnimationProperties: ItemAnimationProperties(
            // Navigation Bar's items animation properties.
            duration: Duration(milliseconds: 00),

            /* curve: Curves.ease,*/
          ),
          screenTransitionAnimation: ScreenTransitionAnimation(
            // Screen transition animation on change of selected tab.
            animateTabTransition: false,
            curve: Curves.ease,
            duration: Duration(milliseconds: 00),
          ),
          navBarStyle: NavBarStyle
              .style6, // Choose the nav bar style with this property.
        ),
      ),
    );
  }

  AppBar buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).primaryColor,
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.black),
      actions: [
        IconButton(
          onPressed: () {},
          icon: const Icon(
            Icons.notifications_none_rounded,
            color: Colors.black,
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(
            Icons.person_outline,
            color: Colors.black,
          ),
        ),
      ],
      title: Center(
        child: const Image(
          image: AssetImage(LOGO_IMAGE_BLACK),
          width: 100,
          height: 50,
        ),
      ),
    );
  }

  List<Widget> buildScreens() {
    return [
      Screen1(),
      Screen2(),
      Screen3(),
      Screen4(),
      Screen5(),
    ];
  }

  List<PersistentBottomNavBarItem> navBarsItems() {
    return [
      PersistentBottomNavBarItem(
        icon: Icon(Icons.home),
        contentPadding: 5,
        title: "\n Home",
        textStyle: TextStyle(
          fontSize: 14,
          fontFamily: 'Lato',
        ),
        activeColorPrimary: Color(0xffEC297B),
        inactiveColorPrimary: Colors.grey,
      ),
      PersistentBottomNavBarItem(
        contentPadding: 5,
        icon: Icon(Icons.woman),
        title: ("Discover Girls"),
        textStyle: TextStyle(
          fontSize: 14,
          fontFamily: 'Lato',
        ),
        activeColorPrimary: Color(0xffEC297B),
        inactiveColorPrimary: Colors.grey,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.calendar_today_outlined),
        title: ("\n Create Event"),
        textStyle: TextStyle(
          fontSize: 14,
          fontFamily: 'Lato',
        ),
        activeColorPrimary: Color(0xffEC297B),
        inactiveColorPrimary: Colors.grey,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.help_outline),
        contentPadding: 5,
        title: ("\n FAQ"),
        textStyle: TextStyle(
          fontSize: 14,
          fontFamily: 'Lato',
        ),
        activeColorPrimary: Color(0xffEC297B),
        inactiveColorPrimary: Colors.grey,
      ),
      PersistentBottomNavBarItem(
        icon: Icon(Icons.settings),
        contentPadding: 5,
        title: ("\n Profile"),
        textStyle: TextStyle(
          fontSize: 14,
          fontFamily: 'Lato',
        ),
        activeColorPrimary: Color(0xffEC297B),
        inactiveColorPrimary: Colors.grey,
      ),
    ];
  }

  Widget Screen1() {
    return HomeView();
  }

  Widget Screen2() {
    return DiscoverGirlView();
  }

  Widget Screen3() {
    return Container(
      color: Colors.white,
    );
  }

  Widget Screen4() {
    return FaqNewView();
  }

  Widget Screen5() {
    return SettingsView();
  }
}
